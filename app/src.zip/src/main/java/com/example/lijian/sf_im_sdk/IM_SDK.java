package com.example.lijian.sf_im_sdk;

import android.widget.ListView;
import android.widget.TextView;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import android.os.Handler;

public class IM_SDK {

    static {
        System.loadLibrary("SF_IM_SDK");
        System.loadLibrary("Android_IM_SDK");
    }

    public IM_SDK(){
    }

    public void setCalReCallBackListenner(OnGetInterface callback){
      this.m_callback = callback;
    }

    //登录状态回调LOGIN_RESCODE rescode
    public void OnGetLoginState(int rescode){
        this.m_callback.GetLoginStaete(rescode);
        return;
    }

    //接收消息
    public void onGetMsgData(int resCode,int fromUserRole,String userID,String	fromUsernam,String fromUserHead,String  fromUerGroupID,String  fromGroup,String   msgTime,String   msgcontent)
    {
        System.out.println("消息内容： " + msgcontent + "名字： " + userID + "时间 " + msgTime );
        MsgContent item = new MsgContent(fromUsernam,msgTime,msgcontent);
        m_callback.AddItem(item);
    }

    //发消息回调
    public void onSendMsgData(int resCode,String userID)
    {
        System.out.println("消息内容： " + resCode + "名字： " + userID);
        return;
    }

    //接收禁言消息
    public void onGetDisableSend(int sendType, int resCode ,int forbidType, String userId, String username, String time){

        System.out.println("用户名： " + username + "时间 " + time +    sendType );
    }

    OnGetInterface m_callback = null;

    public native int InitSDK(int type, String userID ,String userName, String groupID,
                                String userGroup,String serverIp,String userHeadPortrait,int port);

    public native void ConnectMsgServer();

    public native void SendMsg(String msgdata ,int size);

    public native void ForbidSendMsg(int send_Type , int forbidType ,String userID, String userNname, String time);

    public native void DisConnServer();

    public native int GetServerTime();

    //public native void OnIMCallbackListener(OncallBackListener listener);
}
